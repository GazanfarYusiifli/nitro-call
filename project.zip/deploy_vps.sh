#!/bin/bash
# Nitro Call NEW Automated Deployment Script (Shared Hosting)

USER="fittekjk"
IP="198.54.116.81"
PORT="21098"
KEY="/Users/gazanfaryusifli/.ssh/id_rsa_fittekjk_mac"
DEST_PATH="/home/fittekjk/nitro-call"
DOMAIN="fitty.sbs"

echo "🚀 Starting Nitro Call Deployment to $IP on port $PORT..."

# 1. Sync files from LOCAL to Shared Hosting
echo "📦 Syncing files (Using new Mac identity file)..."
rsync -avz -e "ssh -p $PORT -i $KEY -o StrictHostKeyChecking=no" --exclude 'node_modules' --exclude '.git' --exclude 'dist' ./ $USER@$IP:$DEST_PATH

if [ $? -ne 0 ]; then
    echo "❌ Sync failed."
    exit 1
fi

# 2. Run Setup on Hosting
echo "⚙️  Configuring server..."
ssh -p $PORT -i $KEY -o StrictHostKeyChecking=no $USER@$IP <<EOF
    # Setup Node environment
    export PATH=\$PATH:/usr/local/bin
    
    # Backend
    cd $DEST_PATH/backend
    npm install
    
    # Check if pm2 is available
    if command -v pm2 &> /dev/null; then
        pm2 restart server.js --name "nitro-backend" || pm2 start server.js --name "nitro-backend"
    else
        echo "⚠️ PM2 not found. Starting backend with nohup..."
        nohup node server.js > backend.log 2>&1 &
    fi
    
    # Frontend
    cd $DEST_PATH/frontend
    npm install
    echo "VITE_BACKEND_URL=https://\$DOMAIN" > .env
    npm run build
    
    echo "✅ Setup complete! Move the 'dist' contents to your public_html folder manually or fix Nginx if you have access."
EOF
