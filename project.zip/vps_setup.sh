#!/bin/bash
# Nitro Call VPS Deployment Script

echo "🚀 Starting Nitro Call Setup on 76.13.156.87..."

# 1. Update and Dependencies
sudo apt update && sudo apt upgrade -y
sudo apt install -y nodejs npm nginx certbot python3-certbot-nginx git pm2

# 2. Setup App Directory
sudo mkdir -p /var/www/nitro-call
sudo chown -R $USER:$USER /var/www/nitro-call
cd /var/www/nitro-call

# 3. Clone / Copy Code (Assuming user will push to GitHub first)
# git clone YOUR_REPO_URL .

# 4. Setup Backend
cd backend
npm install
pm2 start server.js --name "nitro-backend"
cd ..

# 5. Setup Frontend
cd frontend
npm install
# Update .env for production
echo "VITE_BACKEND_URL=https://fitty.sbs" > .env
npm run build
cd ..

# 6. Configure Nginx
sudo tee /etc/nginx/sites-available/fitty.sbs <<EOF
server {
    listen 80;
    server_name fitty.sbs www.fitty.sbs;

    location / {
        root /var/www/nitro-call/frontend/dist;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }

    location /socket.io {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Security Headers for WebRTC
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
}
EOF

sudo ln -s /etc/nginx/sites-available/fitty.sbs /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx

# 7. SSL Certificate (CRITICAL for Camera/Mic)
echo "--------------------------------------------------------"
echo "🌐 NEXT STEPS:"
echo "1. Go to your Domain Registrar (Hostinger/GoDaddy/etc.)"
echo "2. Add an A record for 'fitty.sbs' pointing to 76.13.156.87"
echo "3. Wait 5-10 minutes for DNS to propagate."
echo "4. RUN THIS COMMAND ON YOUR VPS:"
echo "   sudo certbot --nginx -d fitty.sbs -d www.fitty.sbs"
echo "--------------------------------------------------------"

echo "✅ Deployment structure complete! Run Step 4 above once DNS is ready."
