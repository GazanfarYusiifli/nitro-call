import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mic, MicOff, Video, VideoOff, User } from 'lucide-react';

const ParticipantList = ({ participants, currentUser, onClose }) => {
    return (
        <motion.div 
            initial={{ x: 350 }}
            animate={{ x: 0 }}
            exit={{ x: 350 }}
            className="chat-sidebar participant-list"
        >
            <div className="chat-header">
                <h3>Participants ({participants.length + 1})</h3>
                <button onClick={onClose} className="control-btn" style={{ width: '32px', height: '32px' }}>
                    <X size={18} />
                </button>
            </div>
            
            <div className="participants-area">
                <div className="participant-item me">
                    <div className="participant-info">
                        <div className="avatar">
                            <User size={16} />
                        </div>
                        <span>{currentUser} (You)</span>
                    </div>
                </div>

                {participants.map(p => (
                    <div key={p.peerID} className="participant-item">
                        <div className="participant-info">
                            <div className="avatar">
                                <User size={16} />
                            </div>
                            <span>{p.username}</span>
                        </div>
                        <div className="participant-status">
                            {p.status === 'connected' ? <span className="status-badge connected">Live</span> : <span className="status-badge connecting">...</span>}
                        </div>
                    </div>
                ))}
            </div>
        </motion.div>
    );
};

export default ParticipantList;
