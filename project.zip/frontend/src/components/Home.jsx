import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Video, Zap, User, ArrowRight, Shield, Globe, Zap as ZapIcon } from 'lucide-react';

const Home = ({ onJoin }) => {
    const [roomID, setRoomID] = useState('');
    const [username, setUsername] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (roomID && username) {
            onJoin(roomID, username);
        }
    };

    const createRoom = () => {
        const id = Math.random().toString(36).substring(2, 9);
        setRoomID(id);
    };

    return (
        <div className="home-container">
            <div className="animated-bg">
                <div className="blob"></div>
                <div className="blob"></div>
                <div className="blob"></div>
            </div>

            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="home-content"
            >
                <header className="home-header">
                    <div className="logo-container">
                        <div className="logo-icon">
                            <Video size={32} />
                        </div>
                        <h1>Nitro Call</h1>
                    </div>
                    <p className="subtitle">Premium Peer-to-Peer Video Communication</p>
                </header>

                <main className="glass-card main-card">
                    <form onSubmit={handleSubmit} className="home-form">
                        <div className="input-group">
                            <label><User size={16} /> Username</label>
                            <input 
                                type="text" 
                                placeholder="How should we call you?" 
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </div>

                        <div className="input-group">
                            <label><Zap size={16} /> Room ID</label>
                            <div className="input-with-button">
                                <input 
                                    type="text" 
                                    placeholder="Enter or generate ID" 
                                    value={roomID}
                                    onChange={(e) => setRoomID(e.target.value)}
                                    required
                                />
                                <button 
                                    type="button" 
                                    onClick={createRoom}
                                    className="icon-btn"
                                    title="Generate ID"
                                >
                                    <ZapIcon size={18} />
                                </button>
                            </div>
                        </div>

                        <button type="submit" className="primary-btn">
                            <span>Join Meeting</span>
                            <ArrowRight size={20} />
                        </button>
                    </form>
                </main>

                <footer className="home-features">
                    <div className="feature">
                        <Shield size={20} />
                        <span>Secure P2P</span>
                    </div>
                    <div className="feature">
                        <Globe size={20} />
                        <span>No Install</span>
                    </div>
                    <div className="feature">
                        <ZapIcon size={20} />
                        <span>Low Latency</span>
                    </div>
                </footer>
            </motion.div>
        </div>
    );
};

export default Home;
