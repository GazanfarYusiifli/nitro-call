import React, { useEffect, useRef, useState } from "react";
import io from "socket.io-client";
import Peer from "simple-peer";
import { motion, AnimatePresence } from "framer-motion";
import { Hand } from "lucide-react";
import Controls from "./Controls";
import Chat from "./Chat";
import ParticipantList from "./ParticipantList";
import EmojiPanel from "./EmojiPanel";

import { Buffer } from 'buffer';

const playSound = (type) => {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    const now = audioCtx.currentTime;

    if (type === 'message') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.1, now + 0.05);
        gain.gain.linearRampToValueAtTime(0, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
    } else if (type === 'join') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.2);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.1, now + 0.1);
        gain.gain.linearRampToValueAtTime(0, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
    } else if (type === 'hand') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(440, now + 0.1);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.05, now + 0.05);
        gain.gain.linearRampToValueAtTime(0, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
    } else if (type === 'leave') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(220, now + 0.2);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.1, now + 0.05);
        gain.gain.linearRampToValueAtTime(0, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
    }
};

const Room = (props) => {
    // ...
    const [peers, setPeers] = useState([]); // { peerID, username, stream, status, isResedHand }
    const [messages, setMessages] = useState([]);
    const [isChatOpen, setIsChatOpen] = useState(false);
    const [isParticipantsOpen, setIsParticipantsOpen] = useState(false);
    const [isHandRaised, setIsHandRaised] = useState(false);
    const [showEmojiPanel, setShowEmojiPanel] = useState(false);
    const [floatingEmojis, setFloatingEmojis] = useState([]); // { id, emoji, senderID }
    const socketRef = useRef();
    const userVideo = useRef();
    const peersRef = useRef([]); // { peerID, peer }
    const streamRef = useRef();
    const roomID = props.roomID;

    useEffect(() => {
        const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "";
        socketRef.current = io(BACKEND_URL);
        
        // --- SOCKET LISTENERS (OUTSIDE MEDIA BLOCK) ---
        
        socketRef.current.on("all-users", users => {
            console.log("Existing users in room:", users);
            setPeers(users.map(user => ({
                peerID: user.id,
                username: user.username,
                stream: null,
                status: 'connecting',
                isHandRaised: false
            })));
            
            // We'll initiate connections once we have our own stream
            if (streamRef.current) {
                users.forEach(user => {
                    initiatePeerConnection(user.id, user.username, streamRef.current);
                });
            }
        });

        socketRef.current.on("user-joined", ({ id, username }) => {
            console.log("New user joined room:", username);
            playSound('join');
            setPeers(prev => [...prev.filter(p => p.peerID !== id), {
                peerID: id,
                username: username,
                stream: null,
                status: 'connecting',
                isHandRaised: false
            }]);
        });

        socketRef.current.on("user-joined-signal", payload => {
            console.log("Receiving signal from:", payload.username);
            const existing = peersRef.current.find(p => p.peerID === payload.callerID);
            
            if (existing) {
                existing.peer.signal(payload.signal);
                return;
            }

            // We need our stream to respond
            if (!streamRef.current) {
                console.warn("Received signal before local stream ready, deferred.");
                return; 
            }

            const peer = addPeer(payload.signal, payload.callerID, streamRef.current);
            peersRef.current.push({ peerID: payload.callerID, peer });

            peer.on("stream", remoteStream => {
                setPeers(prev => prev.map(p => p.peerID === payload.callerID ? { ...p, stream: remoteStream, status: 'connected' } : p));
            });
            peer.on("connect", () => {
                setPeers(prev => prev.map(p => p.peerID === payload.callerID ? { ...p, status: 'connected' } : p));
            });
        });

        socketRef.current.on("receiving-returned-signal", payload => {
            const item = peersRef.current.find(p => p.peerID === payload.id);
            if (item) item.peer.signal(payload.signal);
        });

        socketRef.current.on("user-left", id => {
            console.log("User left:", id);
            playSound('leave');
            const peerObj = peersRef.current.find(p => p.peerID === id);
            if (peerObj) peerObj.peer.destroy();
            peersRef.current = peersRef.current.filter(p => p.peerID !== id);
            setPeers(prev => prev.filter(p => p.peerID !== id));
        });

        socketRef.current.on("receive-message", message => {
            playSound('message');
            setMessages(prev => [...prev, message]);
        });

        socketRef.current.on("user-hand-raised", ({ id, isRaised }) => {
            console.log("Remote hand raise event:", id, isRaised);
            if (isRaised) playSound('hand');
            setPeers(prev => prev.map(p => p.peerID === id ? { ...p, isHandRaised: isRaised } : p));
        });

        socketRef.current.on("receive-emoji", ({ id, emoji }) => {
            console.log("Remote emoji event:", id, emoji);
            const newEmoji = { id: Math.random(), emoji, senderID: id };
            setFloatingEmojis(prev => [...prev, newEmoji]);
            setTimeout(() => {
                setFloatingEmojis(prev => prev.filter(e => e.id !== newEmoji.id));
            }, 3000);
        });

        // --- MEDIA STREAM SETUP ---

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert("Camera/Mic access is only allowed in secure contexts (localhost or HTTPS).");
            return;
        }

        navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then(stream => {
            userVideo.current.srcObject = stream;
            streamRef.current = stream;
            
            socketRef.current.emit("join-room", roomID, props.username);
            
            // If we already have a list of peers from "all-users", connect to them now
            setPeers(prev => {
                prev.forEach(p => {
                    const alreadyConnected = peersRef.current.find(pr => pr.peerID === p.peerID);
                    if (!alreadyConnected) {
                        initiatePeerConnection(p.peerID, p.username, stream);
                    }
                });
                return prev;
            });

        }).catch(err => {
            console.error("Media devices failed:", err);
            socketRef.current.emit("join-room", roomID, props.username); // Still join room for chat
        });

        return () => {
            if (socketRef.current) socketRef.current.disconnect();
            if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
            peersRef.current.forEach(p => p.peer.destroy());
        };
    }, [roomID, props.username]);

    const initiatePeerConnection = (userID, username, stream) => {
        const peer = createPeer(userID, socketRef.current.id, stream, props.username);
        peersRef.current.push({ peerID: userID, peer });
        
        peer.on("stream", remoteStream => {
            setPeers(prev => prev.map(p => p.peerID === userID ? { ...p, stream: remoteStream, status: 'connected' } : p));
        });
        peer.on("connect", () => {
            setPeers(prev => prev.map(p => p.peerID === userID ? { ...p, status: 'connected' } : p));
        });
    };

    function createPeer(userToSignal, callerID, stream, username) {
        console.log(`Creating initiator peer for ${username} (${userToSignal})`);
        const peer = new Peer({
            initiator: true,
            trickle: false,
            stream,
            config: {
                iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
            }
        });

        peer.on("signal", signal => {
            console.log(`Forwarding signal to ${userToSignal}`);
            socketRef.current.emit("sending-signal", { userToSignal, callerID, signal, username });
        });

        peer.on("error", err => {
            console.error(`Peer error with ${username}:`, err);
        });

        return peer;
    }

    function addPeer(incomingSignal, callerID, stream) {
        console.log(`Adding non-initiator peer for caller ${callerID}`);
        const peer = new Peer({
            initiator: false,
            trickle: false,
            stream,
            config: {
                iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
            }
        });

        peer.on("signal", signal => {
            console.log(`Returning signal to ${callerID}`);
            socketRef.current.emit("returning-signal", { signal, callerID });
        });

        peer.on("error", err => {
            console.error(`Peer error with caller ${callerID}:`, err);
        });

        peer.signal(incomingSignal);

        return peer;
    }

    const shareScreen = () => {
        console.log("Attempting screen share...");
        if (!navigator.mediaDevices.getDisplayMedia) {
            alert("Screen sharing is not supported in this browser or context.");
            return;
        }

        navigator.mediaDevices.getDisplayMedia({ cursor: true }).then(screenStream => {
            const screenTrack = screenStream.getTracks()[0];
            const originalVideoTrack = streamRef.current.getVideoTracks()[0];

            peersRef.current.forEach(({ peer }) => {
                try {
                    if (peer && !peer.destroyed) {
                        peer.replaceTrack(originalVideoTrack, screenTrack, streamRef.current);
                    }
                } catch (err) {
                    console.error("Error replacing track for peer:", err);
                }
            });

            userVideo.current.srcObject = screenStream;

            screenTrack.onended = () => {
                console.log("Screen share ended, restoring camera...");
                peersRef.current.forEach(({ peer }) => {
                    try {
                        if (peer && !peer.destroyed) {
                            peer.replaceTrack(screenTrack, originalVideoTrack, streamRef.current);
                        }
                    } catch (err) {
                        console.error("Error restoring track for peer:", err);
                    }
                });
                userVideo.current.srcObject = streamRef.current;
            };
        }).catch(err => {
            console.error("Screen share failed:", err);
        });
    };

    const sendMessage = (text) => {
        const msg = {
            sender: props.username,
            text,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        socketRef.current.emit("send-message", msg);
        // Removed local setMessages to prevent duplicates since server broadcasts to all (including sender)
    };

    const toggleHandRaise = () => {
        const newState = !isHandRaised;
        setIsHandRaised(newState);
        console.log("Toggling hand raise to:", newState);
        socketRef.current.emit('toggle-hand-raise', newState);
    };

    const sendEmoji = (emoji) => {
        socketRef.current.emit('emoji-reaction', emoji);
        // Also show locally
        const newEmoji = { id: Date.now(), emoji, senderID: socketRef.current.id };
        setFloatingEmojis(prev => [...prev, newEmoji]);
        setTimeout(() => {
            setFloatingEmojis(prev => prev.filter(e => e.id !== newEmoji.id));
        }, 3000);
    };

    return (
        <div style={{ height: '100vh', width: '100vw', backgroundColor: '#0f172a', display: 'flex', overflow: 'hidden', position: 'relative' }}>
            <AnimatePresence>
                {floatingEmojis.map(e => (
                    <motion.div
                        key={e.id}
                        initial={{ y: 0, x: -20, opacity: 0, scale: 0.5 }}
                        animate={{ y: -400, x: Math.random() * 100 - 50, opacity: 1, scale: 1.5 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 2.5, ease: "easeOut" }}
                        className="floating-emoji"
                        style={{ 
                            left: e.senderID === socketRef.current.id ? '20%' : '70%',
                            zIndex: 9999
                        }}
                    >
                        {e.emoji}
                    </motion.div>
                ))}
            </AnimatePresence>

            <div className="participant-badge">
                <div className="pulse-dot"></div>
                {peers.length + 1} {peers.length + 1 === 1 ? 'Participant' : 'Participants'}
                <span className="mx-2 text-slate-500">|</span>
                <span className="text-slate-300">Room: {roomID}</span>
            </div>
            
            <div style={{ flex: 1, position: 'relative' }}>
                <div className="video-grid">
                    <div className="video-container">
                        <video muted ref={userVideo} autoPlay playsInline />
                        <div className="username-tag">{props.username} (You)</div>
                        {isHandRaised && (
                            <div className="hand-raise-badge">
                                <Hand size={14} fill="currentColor" /> Raised
                            </div>
                        )}
                    </div>
                    {peers.map((peer) => (
                        <Video key={peer.peerID} stream={peer.stream} username={peer.username} status={peer.status} isHandRaised={peer.isHandRaised} />
                    ))}
                </div>
                
                <Controls 
                    stream={streamRef.current} 
                    onLeave={props.onLeave}
                    onShareScreen={shareScreen}
                    onToggleChat={() => setIsChatOpen(!isChatOpen)}
                    onToggleParticipants={() => setIsParticipantsOpen(!isParticipantsOpen)}
                    onRaiseHand={toggleHandRaise}
                    onShowEmojis={() => setShowEmojiPanel(!showEmojiPanel)}
                    isHandRaised={isHandRaised}
                />
                
                <AnimatePresence>
                    {showEmojiPanel && (
                        <EmojiPanel 
                            onSelect={sendEmoji} 
                            onClose={() => setShowEmojiPanel(false)} 
                        />
                    )}
                </AnimatePresence>
            </div>
            
            <AnimatePresence>
                {isChatOpen && (
                    <Chat 
                        messages={messages} 
                        onSendMessage={sendMessage} 
                        onClose={() => setIsChatOpen(false)} 
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {isParticipantsOpen && (
                    <ParticipantList 
                        participants={peers} 
                        currentUser={props.username}
                        onClose={() => setIsParticipantsOpen(false)} 
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

const Video = (props) => {
    const ref = useRef();

    useEffect(() => {
        if (props.stream && ref.current) {
            console.log("Setting stream to video element for:", props.username);
            ref.current.srcObject = props.stream;
            
            // Explicitly play to handle browser autoplay policies
            const playPromise = ref.current.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.log("Autoplay prevented, requires user interaction:", error);
                });
            }
        }
    }, [props.stream]);

    return (
        <div className="video-container">
            <video playsInline autoPlay ref={ref} />
            <div className="username-tag">{props.username}</div>
            {props.isHandRaised && (
                <div className="hand-raise-badge">
                    <Hand size={14} fill="currentColor" /> Raised
                </div>
            )}
            {props.status !== 'connected' && (
                <div className="connection-status">
                    <span className={`status-dot status-${props.status || 'connecting'}`}></span>
                    {props.status === 'error' ? 'Connection Failed' : 'Connecting...'}
                </div>
            )}
        </div>
    );
};

export default Room;
